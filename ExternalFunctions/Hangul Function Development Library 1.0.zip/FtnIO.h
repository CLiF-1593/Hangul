#pragma once
#include "HFDL.h"

void SetInputValue(Hangul* func, int argc, char* argv[]);
wstring SetReturnValue(Hangul* func, Variable &return_value);