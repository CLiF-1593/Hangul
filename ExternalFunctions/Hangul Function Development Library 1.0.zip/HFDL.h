#pragma once
#include "MemorySystem.h"
using namespace std;

class Hangul {
public:
	vector<Variable> parameter_value;
	vector<vector<Variable>> parameter_list;
	Variable Function(); //TODO : Define The Function
};
